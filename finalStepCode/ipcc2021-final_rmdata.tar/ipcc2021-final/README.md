# latticechina

```bash
#compile app for example
cd src
source /public1/soft/modules/module.sh
module load mpi/intel/2017.5
make clean
make
