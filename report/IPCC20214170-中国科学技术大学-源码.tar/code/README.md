## IPCC2021 Final 优化原代码

### 队伍

IPCC20214170 鸿雁超算队2 队长：付佳伟

## 运行前必做事项

1. 将ipcc_gauge_24_72和ipcc_gauge_32_64加入final_case12/data里
2. 将ipcc_gauge_48_96加入final_case3/data里

## 运行
```

cd final_case12/src
sbatch sub_case1.sh
cat case1.log

sbatch sub_case2.sh
cat case2.log

cd ../..
cd final_case3/src
sbatch sub_case3.sh
cat case3.log
```
